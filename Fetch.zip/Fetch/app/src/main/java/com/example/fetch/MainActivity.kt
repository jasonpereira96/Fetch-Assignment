package com.example.fetch

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.fetch.models.Item
import com.example.fetch.ui.theme.FetchTheme
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.fetch.network.NetworkManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            FetchTheme {
                MainScreen()
            }
        }
        fetch { }
    }

}
@Composable
fun MainScreen() {
    var items by remember {
        mutableStateOf(
            listOf(
                Item(
                    1,
                    2, "Jason"
                )
            )
        )
    }
    LaunchedEffect(true) {
        fetch { items = it }
        // Show snackbar using a coroutine, when the coroutine is cancelled the
        // snackbar will automatically dismiss. This coroutine will cancel whenever
        // `state.hasError` is false, and only start when `state.hasError` is true
        // (due to the above if-check), or if `scaffoldState.snackbarHostState` changes.
    }
    // A surface container using the 'background' color from the theme
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colors.background
    ) {
        Row {
            Conversation(
                items
            )
        }
    }
}

fun fetch(callback: (items: List<Item>) -> Unit) {
    val networkManager = NetworkManager()
    networkManager.fetch(callback)
    callback(listOf(Item(1, 2, "Jason")))
}

@Composable
fun HelloContent() {
    Column(modifier = Modifier.padding(16.dp)) {
        var name by remember { mutableStateOf("") }
        if (name.isNotEmpty()) {
            Text(
                text = "Hello, $name!",
                modifier = Modifier.padding(bottom = 8.dp),
            )
        }
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Name") }
        )
    }
}


@Composable
fun MessageCard(msg: Item) {
    // Add padding around our message
    Row(modifier = Modifier.padding(all = 8.dp).background(Color.Cyan).fillMaxWidth()) {

        Column(modifier = Modifier.background(Color.Green)) {
            Text(text = "Name: " + msg.name.toString())
            // Add a vertical space between the author and message texts
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Id: " + msg.id.toString())
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "List Id: " + msg.listId.toString())
        }
    }
}

@Composable
fun Conversation(messages: List<Item>) {
    LazyColumn {
        items(messages) { message ->
            MessageCard(message)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewMessageCard() {
    MessageCard(
        msg = Item(1, 2, "Jason")
    )
}

