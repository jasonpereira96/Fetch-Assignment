package com.example.fetch.models

data class Item(
    val id : Int,
    val listId : Int,
    val name: String? = null
)